@if(!empty(filter_static_option_value('site_google_analytics', $global_static_field_data)))
    {!! filter_static_option_value('site_google_analytics', $global_static_field_data) !!}
@endif
