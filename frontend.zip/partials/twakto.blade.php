@if(!empty(get_static_option('tawk_api_key')))
    {!! get_static_option('tawk_api_key') !!}
@endif
