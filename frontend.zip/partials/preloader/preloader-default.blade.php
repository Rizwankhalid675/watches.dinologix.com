<div class="preloader-inner">
    <ul class="preloader-main">
        <li></li>
        <li></li>
        <li></li>
        <li></li>
        <li></li>
    </ul>
</div>